<?php
//DIMANA ADA KEMAUAN DISITU ADA JALAN
//TETAP BERKARYA WALAU GJLS

$ua = "xxxxxxxxx";


$Cookie = "xxxxxxxxx";

?>